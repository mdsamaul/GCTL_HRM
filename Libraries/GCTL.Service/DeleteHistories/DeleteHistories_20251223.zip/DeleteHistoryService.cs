﻿using Dapper;
using GCTL.Core.Data;
using GCTL.Data.Models;
using GCTL.Service.Common;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SixLabors.ImageSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GCTL.Service.DeleteHistories
{
    public class DependencyCheckResult
    {
        public bool CanDelete { get; set; }
        public List<string> DependentTables { get; set; }
        public string Message { get; set; }

        public DependencyCheckResult()
        {
            DependentTables = new List<string>();
        }
    }

    public class DeleteHistoryService : IDeleteHistoryService
    {
        private readonly IRepository<DeleteHistory> deleteHistoryRepository;
        private readonly GCTL_ERP_DB_DatapathContext context;
        private readonly ICommonService commonService;


        public DeleteHistoryService(IRepository<DeleteHistory> deleteHistoryRepository, GCTL_ERP_DB_DatapathContext context, ICommonService commonService)
        {
            this.deleteHistoryRepository = deleteHistoryRepository;
            this.context = context;
            this.commonService = commonService;
        }

        public async Task<bool> LogDeletedRecordsAsync<T>(List<T> entities, string tableName) where T : class
        {
            if (entities == null || !entities.Any())
                return false;

            try
            {
                var deleteHistoryRecords = new List<DeleteHistory>();
                decimal currentDhid = await GenerateUniqueDHIDAsync();

                foreach (var entity in entities)
                {
                    var deleteHistory = new DeleteHistory
                    {
                        Dhid = currentDhid++,
                        TableName = tableName
                    };

                    var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

                    int fieldIndex;
                    for (fieldIndex = 0; fieldIndex < Math.Min(properties.Length, 99); fieldIndex++)
                    {
                        var property = properties[fieldIndex];
                        var value = property.GetValue(entity);
                        var fieldName = $"Field{fieldIndex + 1}";
                        var fieldValue = value?.ToString();

                        var fieldProperty = typeof(DeleteHistory).GetProperty(fieldName);
                        fieldProperty?.SetValue(deleteHistory, fieldValue);
                    }

                    var jsonFieldName = $"Field{fieldIndex + 1}";
                    var jsonFieldProperty = typeof(DeleteHistory).GetProperty(jsonFieldName);
                    var jsonData = new Dictionary<string, object> { { tableName, entity } };
                    jsonFieldProperty?.SetValue(deleteHistory, JsonSerializer.Serialize(jsonData));

                    deleteHistoryRecords.Add(deleteHistory);
                }

                await deleteHistoryRepository.AddRangeAsync(deleteHistoryRecords);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<List<DeleteHistory>> GetDeletedRecordsByTableAsync(string tableName)
        {
            return await deleteHistoryRepository.All()
                .Where(dh => dh.TableName == tableName)
                .OrderByDescending(dh => dh.AutoId)
                .ToListAsync();
        }

        public async Task<DeleteHistory> GetDeletedRecordByDHIDAsync(decimal dhid)
        {
            return await deleteHistoryRepository.All()
                .FirstOrDefaultAsync(dh => dh.Dhid == dhid);
        }

        private async Task<decimal> GenerateUniqueDHIDAsync()
        {
            var maxDhid = await deleteHistoryRepository.All()
                .MaxAsync(dh => (decimal?)dh.Dhid);

            return (maxDhid ?? 0) + 1;
        }

        public async Task<DependencyCheckResult> CheckDependenciesAsync(
            string tableName,
            string keyField,
            List<object> keyValues,
            List<string> alternateKeyColumns = null)
        {
            try
            {
                var result = new DependencyCheckResult { CanDelete = true };
                if (keyValues == null || !keyValues.Any())
                {
                    result.CanDelete = false;
                    result.Message = "No records to delete";
                    return result;
                }

                // Build list of all columns to search for
                var columnsToSearch = new List<string> { keyField };
                if (alternateKeyColumns != null && alternateKeyColumns.Any())
                {
                    columnsToSearch.AddRange(alternateKeyColumns);
                }

                // Get all tables that have any of these columns
                string query = @"
                    SELECT DISTINCT TABLE_NAME, COLUMN_NAME
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE COLUMN_NAME IN @ColumnNames
                    AND TABLE_NAME != @TableName
                    AND TABLE_SCHEMA = 'dbo'
                    ORDER BY TABLE_NAME
                ";

                using (var conn = new SqlConnection(context.Database.GetConnectionString()))
                {
                    conn.Open();
                    var tableColumns = (await conn.QueryAsync<(string TableName, string ColumnName)>(query,
                        new { ColumnNames = columnsToSearch, TableName = tableName })).ToList();

                    var dependentTables = new List<string>();

                    var tableGroups = tableColumns.GroupBy(tc => tc.TableName);

                    var checkTasks = tableGroups.Select(async tableGroup =>
                    {
                        try
                        {
                            // Create NEW connection for each parallel task
                            using (var taskConn = new SqlConnection(context.Database.GetConnectionString()))
                            {
                                await taskConn.OpenAsync();

                                var table = tableGroup.Key;
                                var valuesList = string.Join(",", keyValues.Select(v =>
                                {
                                    if (v is string || v is Guid)
                                        return $"'{v.ToString().Replace("'", "''")}'";
                                    return v.ToString();
                                }));

                                var conditions = tableGroup.Select(tc =>
                                {
                                    var likePatterns = string.Join(" OR ", keyValues.Select(v =>
                                    {
                                        var formattedValue = (v is string || v is Guid)
                                            ? $"'{v.ToString().Replace("'", "''")}'"
                                            : v.ToString();
                                        return $"',' + CAST([{tc.ColumnName}] AS NVARCHAR(MAX)) + ',' LIKE '%,' + {formattedValue} + ',%'";
                                    }));

                                    return $"([{tc.ColumnName}] IN ({valuesList}) OR {likePatterns})";
                                });

                                string checkQuery = $@"
                                    SELECT CASE WHEN EXISTS (
                                        SELECT 1 FROM [{table}] 
                                        WHERE {string.Join(" OR ", conditions)}
                                    ) THEN 1 ELSE 0 END AS HasRecords
                                ";

                                int hasRecords = await taskConn.ExecuteScalarAsync<int>(checkQuery);
                                return hasRecords == 1 ? table : null;
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine($"Error checking : {ex.Message}");
                            return null;
                        }
                    });

                    var results = await Task.WhenAll(checkTasks);
                    dependentTables = results.Where(t => t != null).ToList();

                    var pageNames = commonService.GetPageNames(dependentTables);

                    if (dependentTables.Any())
                    {
                        result.CanDelete = false;
                        result.DependentTables = dependentTables;
                        result.Message = FormatDependencyMessage(pageNames); ;
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        private string FormatDependencyMessage(List<string> pageNames)
        {
            string interfaces = pageNames.Count switch
            {
                1 => pageNames[0],
                2 => $"{pageNames[0]} & {pageNames[1]}",
                _ => $"{string.Join(", ", pageNames.Take(pageNames.Count - 1))}, & {pageNames.Last()}"
            };

            return $"Can't be deleted. Please remove it from the interface {interfaces} first, respectively";
        }










        //public async Task<DependencyCheckResult> CheckDependenciesAsync(string tableName, string keyField, List<object> keyValues)
        //{
        //    try
        //    {
        //        var result = new DependencyCheckResult { CanDelete = true };

        //        if (keyValues == null || !keyValues.Any())
        //        {
        //            result.CanDelete = false;
        //            result.Message = "No records to delete";
        //            return result;
        //        }

        //        // Step 1: Detect the key field from the table
        //        //var keyField = await DetectKeyFieldAsync(tableName, keyValues.First());


        //        // Step 2: Get all tables that have this key field
        //        string query = @"
        //        SELECT TABLE_NAME
        //        FROM INFORMATION_SCHEMA.COLUMNS
        //        WHERE COLUMN_NAME = @KeyField
        //        AND TABLE_NAME != @TableName
        //        AND TABLE_SCHEMA = 'dbo'
        //        ORDER BY TABLE_NAME
        //    ";



        //        using (var conn = new SqlConnection(context.Database.GetConnectionString()))
        //        {
        //            conn.Open();
        //            var tables = (await conn.QueryAsync<string>(query, new { KeyField = keyField, TableName = tableName })).ToList();

        //            var dependentTables = new List<string>();

        //            // Step 3: Check each table for references (in parallel for better performance)
        //            var checkTasks = tables.Select(async otherTable =>
        //            {
        //                try
        //                {
        //                    // Build IN clause for bulk check
        //                    var valuesList = string.Join(",", keyValues.Select(v =>
        //                    {
        //                        if (v is string || v is Guid)
        //                            return $"'{v.ToString().Replace("'", "''")}'";
        //                        return v.ToString();
        //                    }));

        //                    string checkQuery = $@"
        //                        SELECT CASE WHEN EXISTS (
        //                            SELECT 1 FROM [{otherTable}] 
        //                            WHERE [{keyField}] IN ({valuesList})
        //                        ) THEN 1 ELSE 0 END AS HasRecords
        //                    ";

        //                    int hasRecords = await conn.ExecuteScalarAsync<int>(checkQuery);
        //                    return hasRecords == 1 ? otherTable : null;
        //                }
        //                catch
        //                {
        //                    return null;
        //                }
        //            });

        //            var results = await Task.WhenAll(checkTasks);
        //            dependentTables = results.Where(t => t != null).ToList();

        //            if (dependentTables.Any())
        //            {
        //                result.CanDelete = false;
        //                result.DependentTables = dependentTables;
        //                result.Message = $"Cannot delete. Please delete related records from {string.Join(", ", dependentTables)} first.";
        //            }
        //        }

        //        return result;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw;
        //    }
        //}

    }
}